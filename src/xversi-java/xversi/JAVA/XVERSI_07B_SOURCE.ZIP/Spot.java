public class Spot {

public int x = 0 ;
public int y = 0 ;
public int r ; 

public Spot() {
r = 1 ;
}

public Spot(int R) {
r = R ;
}



}
