cc main.c board.c power2.c agent.c -o xversi
