#define POWER_SIZE 32

void InitPower(void) ;
int GetPower(int n) ;

int power[POWER_SIZE] ;


