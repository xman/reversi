void InitAgent(void) ;
int CheckMove(int , int , int) ;
int MakeMove(int , int , int) ;
int UndoMove(void) ;
int GenerateMove(int) ;


int moveList[65] ; 



